<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Serverws extends CI_Controller 
{

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	function __construct()
	{
		parent::__construct();
		//Variable initialization
		$this->load->model('file_functions');
		$this->load->database();
	}

	public function index()
	{
		$arrayResults = array();

		$user = $this->input->post('in_username');
		$pass = $this->input->post('in_password');
		//$query = $this->db->query('SELECT * FROM users');
		$query = $this->db->get_where('users', array('username' => $user) );

		if( count( $query->result() ))
		{
			$row = $query->row();

			//$result = $this->file_functions->passTreatment($pass);
			//$result = password_hash($pass, PASSWORD_DEFAULT);

			if( password_verify($row->password, $pass) )
			{
				//$arrayResults['connection'] = password_verify($row->password, $result);//$result;
				$arrayResults['connection'] = true;
				//$arrayResults['token'] = password_hash($row->password, PASSWORD_DEFAULT);//password_hash($pass, PASSWORD_DEFAULT);
			}
			else
				$arrayResults['connection'] = false;
		}
		else
			$arrayResults['connection'] = false;

		echo json_encode($arrayResults);
	}

	public function testFunction()
	{
		echo "SiFunca";
	}
}
