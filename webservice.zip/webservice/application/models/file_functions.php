<?php 
	defined('BASEPATH') OR exit('No direct script access allowed');

class File_Functions extends CI_Model
{
	function __construct()
	{
		parent::__construct();
		//Variable initialization
		//$this->load->helper('passTreatment');
	}

	public function passTreatment($in_password)
	{
		return true;
	}
}